package com.itri.sleeveemgdemo

/**
 * Created by HabaCo on 2020/5/7.
 */
data class Record(val time: Long, val value: Int)